import { Anime } from './types';

const BASE = 'https://api.jikan.moe/v4';
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// A Jikan limita ~3 requisições/seg, então enfileiramos tudo com um respiro entre elas.
let last = 0;
let chain: Promise<unknown> = Promise.resolve();
const cache = new Map<string, unknown>();

export function jikan<T>(path: string): Promise<T> {
  if (cache.has(path)) return Promise.resolve(cache.get(path) as T);

  const run = async (): Promise<T> => {
    for (let attempt = 0; attempt < 3; attempt++) {
      const wait = Math.max(0, last + 400 - Date.now());
      if (wait) await sleep(wait);
      last = Date.now();
      const res = await fetch(BASE + path);
      if (res.status === 429) {
        await sleep(1200);
        continue;
      }
      if (!res.ok) throw new Error(`Erro ${res.status}`);
      const data = (await res.json()).data as T;
      cache.set(path, data);
      return data;
    }
    throw new Error('Muitas requisições. Tente de novo em instantes.');
  };

  const p = chain.then(run, run);
  chain = p.catch(() => undefined);
  return p;
}

export const getAnime = (id: number) => jikan<Anime>(`/anime/${id}`);
export const searchAnime = (q: string) =>
  jikan<Anime[]>(`/anime?q=${encodeURIComponent(q)}&sfw=true&limit=20&order_by=popularity`);
export const getSeasonNow = () => jikan<Anime[]>('/seasons/now?limit=12&sfw=true');

// Seleção fofinha: IDs do MyAnimeList
export const CURATED_IDS = [
  52991, // Sousou no Frieren
  54492, // Kusuriya no Hitorigoto
  48736, // Sono Bisque Doll wa Koi wo Suru
  6045, // Kimi ni Todoke
  42897, // Horimiya
  38680, // Fruits Basket (2019)
  853, // Ouran High School Host Club
  33352, // Violet Evergarden
  4081, // Natsume Yuujinchou
  34798, // Yuru Camp
];
