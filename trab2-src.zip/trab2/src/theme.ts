export const C = {
  bg: '#FFF4F8',
  card: '#FFFFFF',
  pink: '#FFB3C7',
  pinkSoft: '#FFD9E4',
  rose: '#F2789F',
  roseDark: '#D9507D',
  text: '#5A3548',
  muted: '#A88595',
  lilac: '#EBDDFF',
  mint: '#D8F4E4',
  butter: '#FFF0C2',
};

export const R = { sm: 12, md: 20, lg: 28, pill: 999 };

export const shadow = {
  shadowColor: '#F2789F',
  shadowOpacity: 0.18,
  shadowRadius: 14,
  shadowOffset: { width: 0, height: 6 },
  elevation: 4,
};

export const F = {
  regular: 'Nunito_400Regular',
  semi: 'Nunito_600SemiBold',
  bold: 'Nunito_700Bold',
  black: 'Nunito_800ExtraBold',
};
