import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AnimeCard from '../components/AnimeCard';
import { searchAnime } from '../api';
import { C, F, R, shadow } from '../theme';
import { SavedAnime, toSaved } from '../types';

export default function SearchScreen() {
  const [q, setQ] = useState('');
  const [data, setData] = useState<SavedAnime[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (q.trim().length < 2) {
      setData([]);
      setError('');
      return;
    }
    // espera a pessoa terminar de digitar
    const t = setTimeout(async () => {
      setLoading(true);
      setError('');
      try {
        setData((await searchAnime(q.trim())).map(toSaved));
      } catch (e: any) {
        setError(e.message || 'Algo deu errado. Tente de novo.');
      } finally {
        setLoading(false);
      }
    }, 600);
    return () => clearTimeout(t);
  }, [q]);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <Text style={styles.title}>Buscar</Text>
      <View style={styles.box}>
        <Ionicons name="search" size={18} color={C.rose} />
        <TextInput
          value={q}
          onChangeText={setQ}
          placeholder="Procure um anime…"
          placeholderTextColor={C.muted}
          style={styles.input}
        />
        {loading && <ActivityIndicator size="small" color={C.rose} />}
      </View>

      {error ? <Text style={styles.msg}>{error}</Text> : null}
      {!error && !loading && q.trim().length >= 2 && data.length === 0 && (
        <Text style={styles.msg}>Nenhum anime encontrado para “{q}”.</Text>
      )}
      {q.trim().length < 2 && <Text style={styles.msg}>Digite pelo menos 2 letras para buscar.</Text>}

      <FlatList
        data={data}
        numColumns={2}
        keyExtractor={(a) => String(a.mal_id)}
        columnWrapperStyle={{ gap: 14, paddingHorizontal: 20 }}
        contentContainerStyle={{ gap: 14, paddingBottom: 120, paddingTop: 6 }}
        renderItem={({ item }) => (
          <View style={{ flex: 1 }}>
            <AnimeCard item={item} />
          </View>
        )}
        keyboardShouldPersistTaps="handled"
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  title: { fontFamily: F.black, fontSize: 26, color: C.rose, paddingHorizontal: 20, paddingTop: 8 },
  box: {
    flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#fff', margin: 20,
    paddingHorizontal: 16, height: 50, borderRadius: R.pill, ...shadow,
  },
  input: { flex: 1, fontFamily: F.semi, fontSize: 15, color: C.text },
  msg: { fontFamily: F.semi, color: C.muted, textAlign: 'center', marginTop: 24, paddingHorizontal: 30 },
});
