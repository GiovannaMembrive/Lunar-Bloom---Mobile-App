import React, { useState } from 'react';
import { FlatList, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import AnimeCard from '../components/AnimeCard';
import { useStore } from '../store';
import { C, F, R, shadow } from '../theme';
import { RootStack, WatchingAnime } from '../types';

function WatchingRow({ item }: { item: WatchingAnime }) {
  const nav = useNavigation<NativeStackNavigationProp<RootStack>>();
  const { setEpisode, toggleWatching } = useStore();
  const pct = item.episodes ? Math.min(100, (item.episode / item.episodes) * 100) : 0;

  return (
    <Pressable style={styles.row} onPress={() => nav.navigate('Details', { id: item.mal_id, preview: item })}>
      <Image source={{ uri: item.image }} style={styles.thumb} />
      <View style={{ flex: 1 }}>
        <Text numberOfLines={2} style={styles.rowTitle}>{item.title}</Text>
        <Text style={styles.rowEp}>
          Episódio {item.episode}
          {item.episodes ? ` de ${item.episodes}` : ''}
        </Text>
        {item.episodes ? (
          <View style={styles.bar}>
            <View style={[styles.barFill, { width: `${pct}%` }]} />
          </View>
        ) : null}
        <View style={styles.actions}>
          <Pressable style={styles.round} onPress={() => setEpisode(item.mal_id, item.episode - 1)}>
            <Ionicons name="remove" size={18} color={C.roseDark} />
          </Pressable>
          <Pressable style={[styles.round, { backgroundColor: C.rose }]} onPress={() => setEpisode(item.mal_id, item.episode + 1)}>
            <Ionicons name="add" size={18} color="#fff" />
          </Pressable>
          <Pressable style={styles.done} onPress={() => toggleWatching(item)}>
            <Text style={styles.doneTxt}>Parar</Text>
          </Pressable>
        </View>
      </View>
    </Pressable>
  );
}

export default function MyListScreen() {
  const { favorites, watching } = useStore();
  const [tab, setTab] = useState<'fav' | 'watch'>('watch');

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <Text style={styles.title}>Minha lista</Text>
      <View style={styles.seg}>
        {([['watch', `Assistindo (${watching.length})`], ['fav', `Favoritos (${favorites.length})`]] as const).map(([k, label]) => (
          <Pressable key={k} onPress={() => setTab(k)} style={[styles.segBtn, tab === k && styles.segOn]}>
            <Text style={[styles.segTxt, tab === k && { color: '#fff' }]}>{label}</Text>
          </Pressable>
        ))}
      </View>

      {tab === 'watch' ? (
        <FlatList
          data={watching}
          keyExtractor={(a) => String(a.mal_id)}
          contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 120 }}
          renderItem={({ item }) => <WatchingRow item={item} />}
          ListEmptyComponent={<Text style={styles.empty}>Você ainda não está assistindo nada. Abra um anime e toque em “Estou assistindo”.</Text>}
        />
      ) : (
        <FlatList
          data={favorites}
          numColumns={2}
          keyExtractor={(a) => String(a.mal_id)}
          columnWrapperStyle={{ gap: 14, paddingHorizontal: 20 }}
          contentContainerStyle={{ gap: 14, paddingTop: 6, paddingBottom: 120 }}
          renderItem={({ item }) => (
            <View style={{ flex: 1 }}>
              <AnimeCard item={item} />
            </View>
          )}
          ListEmptyComponent={<Text style={styles.empty}>Nenhum favorito ainda. Toque no coração de um anime para guardar.</Text>}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  title: { fontFamily: F.black, fontSize: 26, color: C.rose, paddingHorizontal: 20, paddingTop: 8 },
  seg: { flexDirection: 'row', backgroundColor: C.pinkSoft, margin: 20, padding: 4, borderRadius: R.pill },
  segBtn: { flex: 1, paddingVertical: 10, borderRadius: R.pill, alignItems: 'center' },
  segOn: { backgroundColor: C.rose },
  segTxt: { fontFamily: F.bold, color: C.roseDark, fontSize: 13 },
  empty: { fontFamily: F.semi, color: C.muted, textAlign: 'center', marginTop: 40, paddingHorizontal: 36, lineHeight: 22 },
  row: { flexDirection: 'row', gap: 14, backgroundColor: '#fff', padding: 12, borderRadius: R.lg, ...shadow },
  thumb: { width: 84, height: 120, borderRadius: R.md, backgroundColor: C.pinkSoft },
  rowTitle: { fontFamily: F.bold, fontSize: 15, color: C.text },
  rowEp: { fontFamily: F.semi, fontSize: 12, color: C.rose, marginTop: 4 },
  bar: { height: 8, borderRadius: 4, backgroundColor: C.pinkSoft, marginTop: 8, overflow: 'hidden' },
  barFill: { height: '100%', backgroundColor: C.rose, borderRadius: 4 },
  actions: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 'auto' },
  round: { width: 34, height: 34, borderRadius: 17, backgroundColor: C.pinkSoft, alignItems: 'center', justifyContent: 'center' },
  done: { marginLeft: 'auto', paddingHorizontal: 12, paddingVertical: 7, borderRadius: R.pill, backgroundColor: C.lilac },
  doneTxt: { fontFamily: F.bold, fontSize: 12, color: '#7B5BB5' },
});
