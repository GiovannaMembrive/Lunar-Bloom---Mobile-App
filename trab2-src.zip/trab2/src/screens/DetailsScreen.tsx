import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { getAnime } from '../api';
import { useStore } from '../store';
import { C, F, R, shadow } from '../theme';
import { Anime, RootStack, toSaved } from '../types';

export default function DetailsScreen({ route, navigation }: NativeStackScreenProps<RootStack, 'Details'>) {
  const { id, preview } = route.params;
  const [anime, setAnime] = useState<Anime | null>(null);
  const [error, setError] = useState('');
  const { isFav, isWatching, toggleFav, toggleWatching } = useStore();

  useEffect(() => {
    getAnime(id).then(setAnime).catch((e) => setError(e.message || 'Não foi possível carregar.'));
  }, [id]);

  const saved = anime ? toSaved(anime) : preview;
  const fav = isFav(id);
  const watching = isWatching(id);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.top}>
        <Pressable style={styles.back} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={22} color={C.roseDark} />
        </Pressable>
        <Pressable style={styles.back} onPress={() => saved && toggleFav(saved)}>
          <Ionicons name={fav ? 'heart' : 'heart-outline'} size={22} color={C.roseDark} />
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 60 }}>
        {saved && (
          <View style={styles.posterWrap}>
            <Image source={{ uri: saved.image }} style={styles.poster} />
          </View>
        )}
        <Text style={styles.title}>{saved?.title}</Text>

        {!anime && !error && <ActivityIndicator color={C.rose} style={{ marginTop: 24 }} />}
        {error ? <Text style={styles.err}>{error}</Text> : null}

        {anime && (
          <>
            <View style={styles.stats}>
              <Stat icon="star" label={anime.score ? anime.score.toFixed(1) : '—'} />
              <Stat icon="film" label={anime.episodes ? `${anime.episodes} eps` : 'Em aberto'} />
              <Stat icon="calendar" label={anime.year ? String(anime.year) : '—'} />
            </View>

            <View style={styles.chips}>
              {anime.genres.map((g) => (
                <View key={g.mal_id} style={styles.chip}>
                  <Text style={styles.chipTxt}>{g.name}</Text>
                </View>
              ))}
            </View>

            <Pressable
              onPress={() => saved && toggleWatching(saved)}
              style={[styles.cta, watching && { backgroundColor: C.lilac }]}
            >
              <Ionicons name={watching ? 'checkmark-circle' : 'play'} size={18} color={watching ? '#7B5BB5' : '#fff'} />
              <Text style={[styles.ctaTxt, watching && { color: '#7B5BB5' }]}>
                {watching ? 'Assistindo agora' : 'Estou assistindo'}
              </Text>
            </Pressable>

            <Text style={styles.h2}>Sinopse</Text>
            <Text style={styles.synopsis}>{anime.synopsis || 'Sem sinopse disponível.'}</Text>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

function Stat({ icon, label }: { icon: keyof typeof Ionicons.glyphMap; label: string }) {
  return (
    <View style={styles.stat}>
      <Ionicons name={icon} size={16} color={C.rose} />
      <Text style={styles.statTxt}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  top: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 20, paddingTop: 6 },
  back: { width: 42, height: 42, borderRadius: 16, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', ...shadow },
  posterWrap: { alignItems: 'center', marginTop: 6, ...shadow },
  poster: { width: 190, height: 270, borderRadius: R.lg, backgroundColor: C.pinkSoft },
  title: { fontFamily: F.black, fontSize: 24, color: C.text, textAlign: 'center', marginTop: 18 },
  err: { fontFamily: F.semi, color: C.roseDark, textAlign: 'center', marginTop: 20 },
  stats: { flexDirection: 'row', justifyContent: 'center', gap: 10, marginTop: 16 },
  stat: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#fff', paddingHorizontal: 14, paddingVertical: 8, borderRadius: R.pill },
  statTxt: { fontFamily: F.bold, color: C.text, fontSize: 13 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8, marginTop: 16 },
  chip: { backgroundColor: C.pinkSoft, paddingHorizontal: 12, paddingVertical: 6, borderRadius: R.pill },
  chipTxt: { fontFamily: F.bold, fontSize: 12, color: C.roseDark },
  cta: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', backgroundColor: C.rose, height: 52, borderRadius: R.pill, marginTop: 22, ...shadow },
  ctaTxt: { fontFamily: F.black, color: '#fff', fontSize: 15 },
  h2: { fontFamily: F.black, fontSize: 18, color: C.text, marginTop: 26 },
  synopsis: { fontFamily: F.regular, fontSize: 14, color: C.text, lineHeight: 22, marginTop: 8 },
});
