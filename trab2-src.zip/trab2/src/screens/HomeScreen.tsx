import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import AnimeCard from '../components/AnimeCard';
import { CURATED_IDS, getAnime, getSeasonNow } from '../api';
import { useStore } from '../store';
import { C, F, R, shadow } from '../theme';
import { RootStack, SavedAnime, toSaved } from '../types';

function Row({ title, data, loading }: { title: string; data: SavedAnime[]; loading: boolean }) {
  return (
    <View style={{ marginTop: 26 }}>
      <View style={styles.rowHead}>
        <Text style={styles.h2}>{title}</Text>
        {loading && <ActivityIndicator size="small" color={C.rose} />}
      </View>
      <FlatList
        horizontal
        data={data}
        keyExtractor={(a) => String(a.mal_id)}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 20, paddingVertical: 10, gap: 14 }}
        renderItem={({ item }) => <AnimeCard item={item} width={140} />}
      />
    </View>
  );
}

export default function HomeScreen() {
  const nav = useNavigation<NativeStackNavigationProp<RootStack>>();
  const { watching } = useStore();
  const [picks, setPicks] = useState<SavedAnime[]>([]);
  const [season, setSeason] = useState<SavedAnime[]>([]);
  const [loadingPicks, setLoadingPicks] = useState(true);
  const [loadingSeason, setLoadingSeason] = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      // carrega um por um para os cards irem aparecendo aos poucos
      for (const id of CURATED_IDS) {
        try {
          const a = await getAnime(id);
          if (alive) setPicks((cur) => [...cur, toSaved(a)]);
        } catch {}
      }
      if (alive) setLoadingPicks(false);
      try {
        const list = await getSeasonNow();
        const seen = new Set<number>();
        const uniq = list.filter((a) => !seen.has(a.mal_id) && seen.add(a.mal_id)).map(toSaved);
        if (alive) setSeason(uniq);
      } catch {}
      if (alive) setLoadingSeason(false);
    })();
    return () => {
      alive = false;
    };
  }, []);

  const next = watching[0];

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.hi}>Olá, florzinha</Text>
            <Text style={styles.brand}>Lunar Bloom</Text>
          </View>
          <View style={styles.bell}>
            <Ionicons name="moon" size={20} color={C.rose} />
          </View>
        </View>

        <LinearGradient colors={['#FFC2D4', '#FF9BB9']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.hero}>
          <Text style={styles.heroTitle}>Animes para assistir com um chá quentinho</Text>
          <Text style={styles.heroSub}>Salve seus favoritos e acompanhe cada episódio.</Text>
          <Pressable style={styles.heroBtn} onPress={() => (nav as any).navigate('Tabs', { screen: 'Buscar' })}>
            <Text style={styles.heroBtnTxt}>Ver seleção</Text>
          </Pressable>
          <Text style={styles.sparkle}>✿</Text>
        </LinearGradient>

        {next && (
          <Pressable
            style={styles.continue}
            onPress={() => nav.navigate('Details', { id: next.mal_id, preview: next })}
          >
            <Ionicons name="play-circle" size={36} color={C.rose} />
            <View style={{ flex: 1 }}>
              <Text style={styles.contLabel}>Continuar assistindo</Text>
              <Text numberOfLines={1} style={styles.contTitle}>{next.title}</Text>
              <Text style={styles.contEp}>Episódio {next.episode}</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={C.muted} />
          </Pressable>
        )}

        <Row title="Seleção fofinha" data={picks} loading={loadingPicks} />
        <Row title="No ar nesta temporada" data={season} loading={loadingSeason} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 8 },
  hi: { fontFamily: F.semi, color: C.muted, fontSize: 14 },
  brand: { fontFamily: F.black, color: C.rose, fontSize: 26 },
  bell: { width: 44, height: 44, borderRadius: 16, backgroundColor: C.pinkSoft, alignItems: 'center', justifyContent: 'center' },
  hero: { margin: 20, marginBottom: 0, borderRadius: 32, padding: 22, overflow: 'hidden', ...shadow },
  heroTitle: { fontFamily: F.black, color: '#fff', fontSize: 22, lineHeight: 28, maxWidth: '80%' },
  heroSub: { fontFamily: F.semi, color: '#fff', opacity: 0.92, marginTop: 8, maxWidth: '75%' },
  heroBtn: { alignSelf: 'flex-start', backgroundColor: '#fff', paddingHorizontal: 18, paddingVertical: 9, borderRadius: R.pill, marginTop: 16 },
  heroBtnTxt: { fontFamily: F.bold, color: C.roseDark },
  sparkle: { position: 'absolute', right: 18, bottom: 6, fontSize: 70, color: 'rgba(255,255,255,0.45)' },
  continue: {
    flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#fff',
    marginHorizontal: 20, marginTop: 18, padding: 14, borderRadius: R.lg, ...shadow,
  },
  contLabel: { fontFamily: F.semi, fontSize: 12, color: C.muted },
  contTitle: { fontFamily: F.bold, fontSize: 15, color: C.text },
  contEp: { fontFamily: F.semi, fontSize: 12, color: C.rose },
  rowHead: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 20 },
  h2: { fontFamily: F.black, fontSize: 19, color: C.text },
});
