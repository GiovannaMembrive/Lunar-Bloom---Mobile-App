# Lunar Bloom 🌸

App mobile (React Native + Expo + TypeScript) que consome a [Jikan API](https://jikan.moe) (MyAnimeList).

**Integrantes:** _(coloque aqui o nome de vocês)_

## Funcionalidades
- Início: seleção fofinha de animes e o que está no ar na temporada
- Buscar animes pelo nome
- Detalhes: nota, episódios, gêneros e sinopse
- Favoritar para assistir depois
- Marcar o que está assistindo e controlar o episódio atual
- Tudo é salvo no aparelho (AsyncStorage)

## Como rodar
```bash
npm install
npx expo install @react-native-async-storage/async-storage expo-linear-gradient expo-font react-native-screens react-native-safe-area-context
npm install @react-navigation/native @react-navigation/native-stack @react-navigation/bottom-tabs @expo-google-fonts/nunito
npx expo start
```
